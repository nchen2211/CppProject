#include<iostream>
#include"Date.h"
using namespace std;

void main()
{
	int date = 0;
	int month = 0;
	int year = 0;

	cout<<"Enter dd/mm/yy respectively"<<endl;
	cin>>date>>month>>year;

	Date date1(date,month,year);
	date1.displayDate();
}