#include<iostream>
#include"Date.h"
using namespace std;

Date::Date(int d, int m, int y)
{
	date = d;
	year = y;
	if(m<1 || m>12)
		month = 1;
	else
		month = m;
}

void Date::setDate(int d)
{
	date = d;
}

int Date::getDate()const
{
	return date;
}

void Date::setMonth(int m)
{
	month = m;
}

int Date::getMonth()const
{
	return month;
}

void Date::setYear(int y)
{
	year = y;
}

int Date::getYear()const
{
	return year;
}

void Date::displayDate() const
{
	int date = getDate();
	int month = getMonth();
	int year = getYear();
	cout<<date<<"/"<<month<<"/"<<year;
}

