#pragma once

class Date
{
public:
	Date(int, int, int);
	void setDate(int);
	int getDate()const;
	void setMonth(int);
	int getMonth()const;
	void setYear(int);
	int getYear()const;
	void displayDate()const;

private:
	int date;
	int month;
	int year;
};
